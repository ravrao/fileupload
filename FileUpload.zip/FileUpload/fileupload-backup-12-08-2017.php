<?php
/*
   Plugin Name: File Upload
   Plugin URI: http://www.tx-contractor.com 
   Description: File Upload.
   Version: 2.0 
   Author: php
   Author URI: http://www.tx-contractor.com/ 
*/
add_action('admin_menu', 'add_fileupload_menu');
function add_fileupload_menu() //Adding submenu under setting menu of plugin File Upload.
{
add_menu_page( 'options-general.php', 'File Upload', 'manage_options', 'fileupload_listing', 'fileupload_listing_function',plugins_url('/FileUpload/fileupload.png'));
add_submenu_page( 'File Upload', 'File Upload', 'Uploading File Upload', 'manage_options', 'fileupload_upload', 'fileupload_add_function');
add_submenu_page( 'File Upload', 'File Upload', 'Uploading File Upload', 'manage_options', 'fileupload_userrespect_Listing', 'fileupload_userrespect_listing_function');
add_submenu_page( 'File Upload', 'File Upload', 'Uploading File Upload', 'manage_options', 'fileupload_edit', 'fileupload_edit_function');
add_submenu_page( 'File Upload', 'File Upload', 'Uploading File Upload', 'manage_options', 'fileupload_insert', 'fileupload_insert_function');
add_submenu_page( 'File Upload', 'File Upload', 'Uploading File Upload', 'manage_options', 'fileupload_update', 'fileupload_updaak_function');
add_submenu_page( 'File Upload', 'File Upload', 'Uploading File Upload', 'manage_options', 'fileupload_delete', 'fileupload_deleak_function');
}
function fileupload_listing_function() //Calling function for Showing banner deatils in a list.
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
$res=$wpdb->get_var("select count(*) from te_users where `ID`!=1 && `ID`!=2");
$no_of_records = 8;
$result1=(int)$res;
$total_pages=ceil($result1 /  $no_of_records);
$pageno = $_REQUEST['page_no'];
if(empty($pageno))
{
$pageno=1;
}
$rs=$wpdb->get_results( "SELECT  * FROM  `te_users` where `ID`!=1 && `ID`!=2 ORDER BY `id` ASC  limit " . ($pageno-1) * $no_of_records. "," . $no_of_records );
?>

<br/><br/>
<p>
<h2>Listing Users</h2>
</p>
<table class="wp-list-table widefat fixed pages" cellspacing="0" width="95%">
<tr><th background-color="#0096df" style="color: white; font-weight: bold;">Name</th>
<th background-color="#0096df" style="color: white; font-weight: bold;">User Name</th>
<th background-color="#0096df" style="color: white; font-weight: bold;"><strong>File Details</strong></th></tr>
<?php
foreach($rs as $row)
{
$business_name=$wpdb->get_row("SELECT  * FROM  `te_add_business` where `id`='".$row->business_id."'"); 
?>
<tr>
<td><?php echo ucfirst($row->display_name); ?></td>
<td><?php echo ucfirst($row->user_login); ?></td>
<td><a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=fileupload_userrespect_Listing&userid=<?php echo $row->ID; ?>"><img src="<?php bloginfo('url') ?>/wp-content/plugins/FileUpload/edit.png"/></a></td>
</tr>
<?php
}
?>
</table>
<a class="PagingText">Page <?php echo $pageno ; ?> of <?php echo $total_pages; ?>.</a>
<?php
for($i=1;$i<=$total_pages;$i++)
{
?>
<a  href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=fileupload_listing&page_no=<?php echo $i; ?>">
<?php echo $i; ?></a>
<?php
}
?>
<style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
   
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #0096df;
    color: white;
}
</style>

<?php
}

function fileupload_userrespect_listing_function() //Calling function for File Upload User Respect Listing banner deatils in a list.
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
$userid=$_REQUEST['userid'];
$res=$wpdb->get_var("select count(*) from te_file_upload where `user_id`='".$userid."'");
$no_of_records = 8;
$result1=(int)$res;
$total_pages=ceil($result1 /  $no_of_records);
$pageno = $_REQUEST['page_no'];
if(empty($pageno))
{
$pageno=1;
}
$rs=$wpdb->get_results( "SELECT  * FROM  `te_file_upload` where `user_id`='".$userid."' ORDER BY `id` DESC  limit " . ($pageno-1) * $no_of_records. "," . $no_of_records );
?>
<br/><br/>
<p style="float:right;">
    <a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=fileupload_listing"><input name="Add banner" id="submit" class="button-primary"  value="Back" type="submit"></a>
<a href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=fileupload_upload&userid=<?php echo $userid; ?>"><input name="Add banner" id="submit" class="button-primary"  value="File Upolad" type="submit"></a>
</p>
<br/><br/>
<p>
<h2>Listing File Uploaded Details</h2>
</p>
<table class="wp-list-table widefat fixed pages" cellspacing="0" width="95%">
<th background-color="#0096df" style="color: white; font-weight: bold;"><strong>User Type</strong></th>
<th background-color="#0096df" style="color: white; font-weight: bold;"><strong>B. Type</strong></th>
<th background-color="#0096df" style="color: white; font-weight: bold;"><strong>Description</strong></th>
<th background-color="#0096df" style="color: white; font-weight: bold;"><strong>Download</strong></th>
<th background-color="#0096df" style="color: white; font-weight: bold;"><strong>Invoice</strong></th>
<th background-color="#0096df" style="color: white; font-weight: bold;"><strong>Amount</strong></th>
<th background-color="#0096df" style="color: white; font-weight: bold;"><strong>Date</strong></th>
<th background-color="#0096df" style="color: white; font-weight: bold;"><strong>Sender</strong></th>

<?php
foreach($rs as $row)
{
$business_name=$wpdb->get_row("SELECT  * FROM  `te_add_business` where `id`='".$row->business_id."'"); 
$urlformat=explode("*",$row->file_upload);
$key='user_type';
$single = true;
?>
<tr>
    <td><?php echo ucfirst(get_user_meta( $userid, $key, $single )); ?></td>
<td><?php echo $business_name->business_name; ?></td>
<td><?php echo $row->description; ?></td>
<td><a href="<?php echo $row->file_upload; ?>" target="blank" download="<?php echo $urlformat[1]; ?>"> <img src="<?php bloginfo('url') ?>/wp-content/plugins/FileUpload/download.png"/></a></td>
<td><?php if($row->invoice=='Bill'){?> <span style="color:red; font-weight: bold;"> <?php } ?>
<?php echo ucfirst($row->invoice); ?><?php if($row->invoice=='Bill'){?></span><?php } ?>
</td>
<td><?php if($row->amount!=0){?><span style="color:red; font-weight: bold;"> <?php } ?><?php echo number_format($row->amount,2); ?><?php if($row->amount!=0){?></span> <?php } ?></td>
<td><?php echo $row->upload_date; ?></td>
<td><?php if($row->sender=='Admin') { ?> <span style="color:red; font-weight: bold;"> <?php } ?><?php echo $row->sender; ?><?php if($row->sender=='Admin') { ?> </span> <?php } ?></td>

</tr>
<?php
}
?>
</table>
<a class="PagingText">Page <?php echo $pageno ; ?> of <?php echo $total_pages; ?>.</a>
<?php
for($i=1;$i<=$total_pages;$i++)
{
?>
<a  href="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=fileupload_userrespect_Listing&page_no=<?php echo $i; ?>">
<?php echo $i; ?></a>
<?php
}
?>
<style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
   
}

tr:nth-child(even){background-color: #f2f2f2}

th {
    background-color: #0096df;
    color: white;
}
</style>

<?php
}
function fileupload_add_function() //Calling function for Adding a new banner.
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
$userid=$_REQUEST['userid'];
?>
<html>
<head>
</head>
<body>
<form name="form" action="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=fileupload_insert&userid=<?php echo $userid ; ?>" method="post" onSubmit="return preview(document.form.picture);" enctype="multipart/form-data">
<table>
<tr><th><h4>You Can File Upload From Here</h4></th></tr>
<tr><td>Select Business Name</td>
<td>
<select name="business_name">
<?php 
$business_name=$wpdb->get_results("SELECT  * FROM  `te_add_business` where `user_id`='".$userid."'");
foreach($business_name as $rowname)
{
?>    
<option value="<?php echo $rowname->id;?>"> <?php echo $rowname->business_name;?></option>
<?php } ?>
</select>
</td>
</tr>
<tr><td>Select File Type</td>
<td>
<select name="file_type">
<option value="Report">Report</option>
<option value="Communication">Communication</option>
<option value="Bill">Bill</option>
</select>
</td>
</tr>
<tr><td>Bill Amount</td>
<td>
    <input type="text" name="bill_amount" value="" size="60" placeholder="Pelase Enter Bill Amount when Bill Type Is Select 'Bill'"/>
</select>
</td>
</tr>
<tr><td>Description:</td><td><textarea name="description" rows="5" cols="60"></textarea></td></tr>
<tr><td>File Upload:</td><td><input type="file" name="picture" value=""  size="25"></td></tr>
<tr><td></td><td><input type="submit" value="Upload File" name="Add" id="post-query-submit" class="button-secondary"/></td></tr>
</table>
</form>
</body>  
</html>
<?php
}
function fileupload_insert_function() // Insert banner Image.
{
if (isset($_POST['Add']))
{
$userid=$_REQUEST['userid'];
$sender='Admin';
$cu_date=date("d/m/Y h:i:s A") ;    
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
$target="../wp-content/plugins/FileUpload/upload/".$_FILES["picture"]["name"];
$img=time().'*'.$_FILES["picture"]["name"];
$target_path = "../wp-content/plugins/FileUpload/upload/".$img;
move_uploaded_file($_FILES['picture']['tmp_name'],$target_path);
$path=get_option('siteurl')."/wp-content/plugins/FileUpload/upload/".$img;
$insert = "INSERT INTO " .  te_file_upload . " (user_id,business_id,file_upload,description,sender,invoice,amount,upload_date) " . "VALUES ('" . $userid . "','" . $_POST['business_name'] . "','" . $path . "','" . $_POST['description'] . "','" . $sender . "','" . $_POST['file_type'] . "','" . $_POST['bill_amount'] . "','" . $cu_date . "')";
$wpdb->query( $insert );
$path=get_option('siteurl');

///////// E-Mail Send Code ///////////////

$user_email=    $wpdb->get_row("SELECT  * FROM `te_users` where `ID`='".$userid."'");
$business_name= $wpdb->get_row("SELECT  * FROM  `te_add_business` where `id`='".$_POST['business_name']."'");
$Emailadmin=    $user_email->user_email;
$file_type=     $_POST['file_type'];
if($_POST['file_type']!='Bill')
{
$bill_amount=   'Not Applicable';
}
else
{
$bill_amount=   number_format($_POST['bill_amount'],2);
}
$description=   $_POST['description'];
$business_name= $business_name->business_name;

$to  = $Emailadmin;
$subject = 'File Sent By Admin';

 $message = '<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>File Sent By Admin</title>
</head>

<body>
    <table width="600" cellpadding="0" cellspacing="0" style="border-collapse:collapse" align="left">

        <tr style="text-align:left;font-size:18px;color:#aa8095">
            <td style="padding-top:15px;padding-bottom:15px; font-family:arial; color:#333; line-height:25px;">Business Name : '.$business_name.'</td>
        </tr> 
        <tr style="text-align:left;font-size:18px;color:#aa8095">
            <td style="padding-top:15px;padding-bottom:15px; font-family:arial; color:#333; line-height:25px;">File Type : '.$file_type.'</td>
        </tr> 
       
        <tr style="text-align:left;font-size:18px;color:#aa8095">
            <td style="padding-top:15px;padding-bottom:15px; font-family:arial; color:#333; line-height:25px;">Bill Amount : '.$bill_amount.'</td>
        </tr>
        <tr style="text-align:left;font-size:18px;color:#aa8095">
            <td style="padding-top:15px;padding-bottom:15px; font-family:arial; color:#333; line-height:25px;">Description : '.$description.'</td>
        </tr> 

    </table>
</body>					
</html>';


// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: wordpress@keepbooks.in';
$send=mail($to, $subject, $message, $headers);
if($send)
{
echo "Message has been successfully sent";
}
 else 
    {
     echo 'Error ! E-Mail not sent';
    }

///////// End here /////////////////////





?>
<script>
document.location.href ="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=fileupload_userrespect_Listing&userid=<?php echo $userid ; ?>";
</script>
<?php		    
}	
}
function fileupload_edit_function() // Calling function for editing banner details.
{
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
global $wpdb;
$id=$_REQUEST['id'];
$rs=$wpdb->get_row("SELECT  * FROM  `ta_fileupload_upload` where `id`='".$id."'");
?>
<form name="form" action="<?php echo get_option('siteurl'); ?>/wp-admin/admin.php?page=fileupload_update&id1=<?php echo $id; ?>" method="post" enctype="multipart/form-data">
<table>
<tr><th><h4>Edit File Upload</h4></th></tr>
<tr><td>Order No:</td><td><input type="text" name="orderno" size="30" value="<?php echo $rs->orderno; ?>" /></td></tr>
<tr><td>Description:</td><td><textarea name="caption" rols="10" cols="50"><?php echo $rs->caption; ?></textarea></td></tr>
<tr><td>File Upload :</td><td><input type="file" name="picture" value=""  size="22"></td></tr>
<tr><td></td><td><input type="submit" value="Update banner" name="Add" id="post-query-submit" class="button-secondary"/></td></tr>
</table>
</form>    
<?php
}
?>
